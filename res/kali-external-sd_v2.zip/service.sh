#!/system/bin/sh

MEMORY_CARD_BLOCK="/dev/block/mmcblk1p1"

if [ -b "$MEMORY_CARD_BLOCK" ]; then

    # create folders
    mkdir -p /mnt/external_sd

    # mount external SD, create folders
    mount ${MEMORY_CARD_BLOCK} /mnt/external_sd
    mkdir -p /data/local/nhsystem /mnt/external_sd/nethunter

    # bind mount /mnt/external_sd/nethunter to /data/local/nhsystem
    mount --bind /mnt/external_sd/nethunter /data/local/nhsystem
fi
